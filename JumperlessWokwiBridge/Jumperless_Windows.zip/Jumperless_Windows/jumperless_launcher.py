#!/usr/bin/env python3
"""
Jumperless Windows Python Launcher Wrapper
Cross-platform launcher that can be executed directly
"""
import os
import sys
import subprocess
import time
import signal

def kill_existing_instances():
    """Kill existing Jumperless instances on Windows"""
    print("Checking for existing Jumperless instances...")
    
    # List of process names to kill
    process_names = [
        "Jumperless.exe",
        "JumperlessWokwiBridge.exe", 
        "Jumperless_cli.exe",
        "jumperless_cli.exe"
    ]
    
    for process_name in process_names:
        try:
            subprocess.run(['taskkill', '/F', '/IM', process_name], 
                          capture_output=True, check=False)
        except:
            pass
    
    # Kill Python processes running JumperlessWokwiBridge
    try:
        result = subprocess.run(['tasklist', '/fo', 'csv'], 
                               capture_output=True, text=True, check=False)
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            for line in lines:
                if 'python' in line.lower() and 'jumperlesswokwibridge' in line.lower():
                    parts = line.split('","')
                    if len(parts) > 1:
                        try:
                            pid = parts[1].strip('"')
                            subprocess.run(['taskkill', '/F', '/PID', pid], 
                                         capture_output=True, check=False)
                        except:
                            pass
    except:
        pass
    
    time.sleep(1)
    print("Cleared existing instances.")

def main():
    """Main launcher function"""
    # Get script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Kill existing instances
    kill_existing_instances()
    
    print("
" + "="*50)
    
    print("    Jumperless Windows Python Launcher")
    print("="*50 + "
")
    
    # Check for Python
    try:
        subprocess.run([sys.executable, '--version'], check=True, capture_output=True)
        print(f"✅ Python found: {sys.executable}")
    except:
        print("❌ Python not working properly")
        input("Press Enter to exit...")
        return 1
    
    # Install requirements
    requirements_file = os.path.join(script_dir, 'requirements.txt')
    if os.path.exists(requirements_file):
        print("📦 Installing Python dependencies...")
        try:
            subprocess.run([sys.executable, '-m', 'pip', 'install', '-r', requirements_file], 
                          check=True)
            print("✅ Dependencies installed")
        except subprocess.CalledProcessError:
            print("⚠️  Warning: Some dependencies may not have installed")
    
    # Run main application
    print("
🚀 Starting Jumperless Bridge...")
    print("="*50)
    
    main_script = os.path.join(script_dir, 'JumperlessWokwiBridge.py')
    if not os.path.exists(main_script):
        print(f"❌ Main script not found: {main_script}")
        input("Press Enter to exit...")
        return 1
    
    try:
        # Change to script directory and run
        os.chdir(script_dir)
        result = subprocess.run([sys.executable, 'JumperlessWokwiBridge.py'] + sys.argv[1:])
        return result.returncode
    except KeyboardInterrupt:
        print("

⚠️  Interrupted by user")
        return 0
    except Exception as e:
        print(f"❌ Error running Jumperless: {e}")
        input("Press Enter to exit...")
        return 1

if __name__ == "__main__":
    sys.exit(main())
