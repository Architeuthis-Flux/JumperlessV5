#!/usr/bin/env python3
"""
Jumperless Windows Python Launcher Wrapper
Cross-platform launcher that can be executed directly
"""
import os
import sys
import subprocess
import time
import signal

def main():
    """Main launcher function"""
    # Get script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    print("
" + "="*50)
    
    print("    Jumperless Windows Python Launcher")
    print("="*50 + "
")
    
    # Check for Python
    try:
        subprocess.run([sys.executable, '--version'], check=True, capture_output=True)
        print(f"✅ Python found: {sys.executable}")
    except:
        print("❌ Python not working properly")
        input("Press Enter to exit...")
        return 1
    
    # Install requirements
    requirements_file = os.path.join(script_dir, 'requirements.txt')
    if os.path.exists(requirements_file):
        print("📦 Installing Python dependencies...")
        try:
            subprocess.run([sys.executable, '-m', 'pip', 'install', '-r', requirements_file], 
                          check=True)
            print("✅ Dependencies installed")
        except subprocess.CalledProcessError:
            print("⚠️  Warning: Some dependencies may not have installed")
    
    # Run main application
    print("
🚀 Starting Jumperless Bridge...")
    print("="*50)
    
    main_script = os.path.join(script_dir, 'JumperlessWokwiBridge.py')
    if not os.path.exists(main_script):
        print(f"❌ Main script not found: {main_script}")
        input("Press Enter to exit...")
        return 1
    
    try:
        # Change to script directory and run
        os.chdir(script_dir)
        result = subprocess.run([sys.executable, 'JumperlessWokwiBridge.py'] + sys.argv[1:])
        return result.returncode
    except KeyboardInterrupt:
        print("

⚠️  Interrupted by user")
        return 0
    except Exception as e:
        print(f"❌ Error running Jumperless: {e}")
        input("Press Enter to exit...")
        return 1

if __name__ == "__main__":
    sys.exit(main())
