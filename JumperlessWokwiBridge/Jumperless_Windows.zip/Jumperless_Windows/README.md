# Jumperless Bridge for Windows (Python Source)

## Quick Start
1. Extract this archive: Right-click Jumperless_Windows.zip -> Extract All
2. Run the launcher: Double-click `jumperless_launcher.bat`

## Requirements
- Python 3.6 or higher (from python.org)
- pip (included with Python)

## Manual Installation
If the launcher doesn't work, you can run manually:

1. Open Command Prompt in the extracted folder
2. Install dependencies:
   ```cmd
   pip install -r requirements.txt
   ```

3. Run the application:
   ```cmd
   python JumperlessWokwiBridge.py
   ```

## Files Included
- `JumperlessWokwiBridge.py` - Main application
- `requirements.txt` - Python dependencies
- `jumperless_launcher.bat` - Windows launcher script
- `README.md` - This file

## Compatibility
This package works on all Windows versions that support Python 3.6+
(Windows 7, 8, 10, 11 - both 32-bit and 64-bit)

## Notes
- The launcher will automatically install Python dependencies
- You may want to use a Python virtual environment
- Make sure Python is added to your PATH during installation

## Troubleshooting
- If "python is not recognized": Reinstall Python and check "Add to PATH"
- If dependencies fail to install: Try running as administrator
- For permission issues: Use `pip install --user -r requirements.txt`

## Support
Visit: https://github.com/Architeuthis-Flux/JumperlessV5
