# Jumperless Bridge for Windows (Python Source)

## Quick Start
1. Extract this archive: Right-click Jumperless_Windows.zip -> Extract All
2. Run the launcher: Double-click `jumperless_launcher.bat`

## Launcher Options
Multiple launcher options are provided for different use cases:

### Option 1: Batch Launchers (Recommended for most users)
- `jumperless_launcher.bat` - Full-featured batch launcher
- `jumperless_launcher.cmd` - Alternative batch launcher (same functionality)

### Option 2: Python Wrapper (For advanced users)
- `jumperless_launcher.py` - Cross-platform Python launcher

### Option 3: Manual Execution
- Run `python JumperlessWokwiBridge.py` directly after installing requirements

## Simple Launcher Features
All launchers provide:
- ✅ Automatic Python dependency installation
- ✅ Clear feedback about terminal environment
- ✅ Graceful error handling and user-friendly messages

## Requirements
- Python 3.6 or higher (from python.org)
- pip (included with Python)

## Manual Installation
If the launcher doesn't work, you can run manually:

1. Open Command Prompt in the extracted folder
2. Install dependencies:
   ```cmd
   pip install -r requirements.txt
   ```

3. Run the application:
   ```cmd
   python JumperlessWokwiBridge.py
   ```

## Files Included
- `JumperlessWokwiBridge.py` - Main application
- `requirements.txt` - Python dependencies
- `jumperless_launcher.bat` - Windows batch launcher
- `jumperless_launcher.cmd` - Alternative batch launcher
- `jumperless_launcher.py` - Python wrapper launcher
- `README.md` - This file

## Compatibility
This package works on all Windows versions that support Python 3.6+
(Windows 7, 8, 10, 11 - both 32-bit and 64-bit)

## Notes
- All launchers automatically install Python dependencies
- You may want to use a Python virtual environment
- Make sure Python is added to your PATH during installation
- Process killing ensures clean startup without conflicts

## Troubleshooting
- If "python is not recognized": Reinstall Python and check "Add to PATH"
- If dependencies fail to install: Try running as administrator
- For permission issues: Use `pip install --user -r requirements.txt`
- If launchers don't work: Try the Python wrapper or manual execution

## Support
Visit: https://github.com/Architeuthis-Flux/JumperlessV5
