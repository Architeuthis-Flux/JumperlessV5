# Jumperless Bridge for Linux

## Quick Start
1. Extract this archive: `tar -xzf Jumperless_Linux.tar.gz`
2. Run the launcher: `./jumperless_launcher.sh`

## Requirements
- Python 3.6 or higher
- pip (Python package installer)

## Manual Installation
If the launcher doesn't work, you can run manually:

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the application:
   ```bash
   python3 JumperlessWokwiBridge.py
   ```

## Files Included
- `JumperlessWokwiBridge.py` - Main application
- `requirements.txt` - Python dependencies
- `jumperless_launcher.sh` - Launcher script
- `README.md` - This file

## Compatibility
This package works on all Linux architectures (x86_64, ARM64, etc.)
since it contains pure Python code.

## Notes
- The launcher will automatically install Python dependencies
- You may want to use a Python virtual environment
- For system-wide installation, you may need sudo for pip install

## Support
Visit: https://github.com/Architeuthis-Flux/JumperlessV5
